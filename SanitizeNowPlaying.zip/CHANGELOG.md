# Changelog

## v3.1.0 — prepared 2026-10-11

- Show complete wrapped toast text in main and initial setup, measuring actual
  font/available width and growing only the message box. Keep wrapped messages
  readable for at least eight seconds. Oversized messages use an owned OK notice;
  long diagnostics are scrollable and selectable/copyable without clipping.
  Preserve the current menu/draft and fixed application dimensions. Add full-text
  raster, long-path/multilingual, final-line, scrolling and acknowledgement probes.
- Correct the Phase 6.8 test build's explicit source list to include
  AppNoticeForm.cs. Automatically check and acknowledge deliberately failed
  quick-save notices without accepting unexpected diagnostics; preserve all
  committed-state, popup and retry assertions. No production change in this fix.
- Record the complete current native Windows VERIFY-ALL PASS: Core 528/0,
  parity 35/0, Runtime 59/0, App-state 35/0, settings/overlay 33/0,
  picker/network 28/0 and QUICK stress 13/0 (14,921 operations), plus every
  actual UI/gate/startup/cleanup group. Final message rendering and both
  test corrections are confirmed. Practical deployment checks remain separate.
- Finalize version metadata, current documentation, source map, release notes
  and distribution names after the native RC4 automatic and actual UI/startup
  verification passed; the current complete native run also confirms the later corrections below.
- Refuse unwritable shared input/output folder choices in initial setup and
  F10 before changing settings. Keep the picker open with a warning toast;
  preserve readable, read-only input when output uses a different directory.
  Cover normalized same-path custom output and permission-recovery retry.
- Fix a quiet-output recovery test race: wait for exact bytes in all six
  output files and completed publication, rather than checking RT+ immediately
  after artist.txt appears. Preserve the existing timeout.
- Keep OUTPUT DIR status/color based on directory availability only. A reachable
  folder with denied writes retains normal availability display; WRITE FAILED
  stays at the affected output files. Preserve destination tooltip diagnostics.
  Add a post-start permission-loss/recovery ACL regression for shared/separate
  destinations and rendered separation checks in Online/Checking/Offline states.
- Show UNAVAILABLE for missing/inaccessible input and output folders, retaining
  CHECKING for output probes and WRITE FAILED only at individual files.
  Do not recreate a deleted/renamed folder from publication, retry, output
  clearing, process-exit cleanup, input-watcher rebuild or session startup.
  Preserve the configured path and resume after its explicit restoration;
  retain explicit picker creation and existing startup-wizard behavior.
  Add delete/rename/publish/retry/clear/exit/watcher/recovery regressions and
  actual rendered UNAVAILABLE checks. Runtime now has 59 cases; application
  state has 34 cases.
- Correct write-permission restoration in the owned test fixture: import the
  original access descriptor into a fresh DirectorySecurity object, so .NET
  Framework persists it on each MakeWritable/Dispose call. Add actual creation
  checks for repeated restoration and disposal; retain all recovery assertions,
  check all six output bytes and include path/state/error diagnostics. Test reads
  allow atomic file replacement. Application-state now has 35 cases. No production
  source changes in this correction; retain the historical native 59/0 Runtime and
  33/1 application-state log. The subsequent current native run passes all 35 cases.
- Include configurable rules, text case, output destination and quick access,
  multilingual/RT length fixes, output recovery, safe settings rollback and
  recovery backups developed during the beta/RC cycle below.
- Provide VERIFY-UI.cmd and VERIFY-ALL.cmd as current names, with aliases for
  previous commands. Retain all zero-exit/exact-completion/error guards.
- Retain historical Windows results and record the later Phase 4 failure.
  The subsequent complete native 35/0 application-state and all-suite PASS
  confirms those fixes and the new display/acknowledgement checks. Practical
  deployment observations remain separate. Picker/network includes 28 cases.

## v3.1.0-rc4 — 2026-10-10

- Correct native UI probe assertions: require contrasting radio rim ink on four
  edge regions instead of one exact antialiased pixel; retain empty/active centers,
  exact dot color, centered geometry, states and marker behavior. Add negative
  visibility controls. Production marker drawing is unchanged.
- Stage actual startup tests in fresh TEMP folders, retry bounded owned-fixture
  cleanup, remove owned readonly flags, retain all errors and copy the screenshot
  back to build. Keep actual notice/diagnostic-path/exit/original-preservation tests.
- Require explicit completion and zero exit for both probes. Catch/report full
  exceptions; crashes and cleanup errors cannot claim PASS. Add native batch gate
  regressions and fix signed failure propagation in build/release/package wrappers.
- Record the supplied fully passing RC3 native automatic chain and separately
  label its failed UI run/false PASS. Keep RC4 a candidate pending corrected native
  UI and manual observations. Production C# changes only in version metadata;
  Core/runtime/App-state and other automatic suite assertions/counts are unchanged.

### RC4 verification script correction — 2026-10-11

- Fix a false rejection in the self-test: a previous expected failure could remain
  in ERRORLEVEL after successful ECHO/DEL. Verify fixture content/removal directly.
  Retain all real crash/zero-status/completion guards and show the failed case.
- Record the supplied fully passing native RC4 automated chain. Its UI attempt
  stopped at the gate self-test before actual menu/startup tests; those remain
  pending. No application version, production C# or actual probe changes.

## v3.1.0-rc3 — 2026-10-10

- Fix recovery-only MAX_PATH failures: keep complete GUID entropy in short,
  filename-safe c-<token>.bak names. The full path, including settings-backups,
  is shorter than the existing settings temp path. Retain exact bytes, CreateNew,
  Flush(true), safe rejection/retry and all earlier backups.
- Add a deep 210-character directory regression with two corrupt saves and retained
  copies (56 Runtime tests). Preserve the original non-object/failure assertions.
  Runtime failures now include full exceptions, inner causes and stacks.
- Record the supplied RC2 native Windows result: Core 528/0, parity 35/0, Runtime
  54/1 at a 261-character recovery path; later suites were not reached. Keep RC3
  as a release candidate pending VERIFY-CANDIDATE.cmd and the native checklist.
- Processing, output formats, runtime recovery, all UI styling and App-state
  assertions remain unchanged. Update version, current documentation and commands.

## v3.1.0-rc2 — 2026-10-10

- Allow at most 300 seconds of future input timestamp skew at startup/reconnect/
  input-path changes; retain the 180-second old-input freshness limit.
- Guard the complete application startup path. Unreadable settings fail with a
  controlled notice, full diagnostic path and original exception, without default
  activation or file replacement. Retain bounded transient-read retries.
- Preserve malformed/non-object settings bytes in unique, flushed .bak copies
  under settings-backups before replacement. Reject saving if recovery fails;
  retain previous copies and active runtime. Valid settings need no recovery copy.
- Add seven Runtime cases (55 total), three App-state cases (30 total) and an actual
  application-entry startup-notice probe. Retain all prior assertions and Core 528.
- Update the packaged release README and missing beta26–33 changelog entries;
  document artist-only compatibility, per-session mutex and per-file atomicity.
  Add VERIFY-CANDIDATE.cmd for the native release/UI/startup verification chain.
- Remain a release candidate until Windows 10/11/.NET Framework 4.8 native checks
  pass; do not claim stable/native I/O verification from local Mono/POSIX runs.

## v3.1.0-beta33 — 2026-10-10

- Apply the shared quiet focus/hover palette to initial setup folder, volume and input-file choices; add actual setup rendering/navigation checks.

## v3.1.0-beta32 — 2026-10-10

- Center all F10 submenus on their immediate parent, with only client-edge clamping; remove the obsolete edge-separation threshold. Preserve manual positions and F10-only Restore defaults.

## v3.1.0-beta31 — 2026-10-10

- Use dark gray focus and subtler hover for menu rows; keep checkbox/radio state colors stable and disabled labels muted.

## v3.1.0-beta30 — 2026-10-10

- Compact measured footer command padding; strengthen filled/hollow checkbox contrast and center radio dots geometrically. Preserve successful quick-choice dismissal.

## v3.1.0-beta29 — 2026-10-10

- Use matching checkbox/radio shapes in quick and F10 choice menus; unify footer action fonts/baselines. Keep undimmed quick popups.

## v3.1.0-beta28 — 2026-10-09

- Narrow the main client to 1008x500 while retaining all five full quick-setting values, footer commands and full-width location paths.

## v3.1.0-beta27 — 2026-10-09

- Return the main client to compact proportions using the existing stable footer font fitting.

## v3.1.0-beta26 — 2026-10-09

- Return F10/Exit to the bottom right and restore full-width INPUT DIR/OUTPUT DIR, retaining all five settings on one footer row.

## v3.1.0-beta25 — 2026-10-05

- Correct remaining Framework 4 recovery diagnostics: explicitly format the nested
  AggregateException so every commit/disk/runtime cause and stack is included. Keep
  the beta24 destination context and both failing Windows assertions. App-state: 27.
- Add Order A→T/T→A to the status row with immediate-save, checked quick choices.
  Support existing mouse switching, Left/Right wrap and Tab/Shift+Tab focus routes.
- Move F10 Settings and Alt+F4 Exit to the top right, retaining hover frames. Reserve
  INPUT DIR path/status width and a clear gap; keep full truncated-value tooltips.
  Retain 999x500 client, complete footer values and stable measured font.
- Narrow Exit confirmation using actual help measurement and compact arrow help;
  retain safe Cancel default, full copy/buttons and existing shutdown behavior.
- Expand UI verification to five popups/seven focus items and 144 configurations,
  including Order persistence, failed-save/retry and long/offline INPUT clearance.
  Core/Runtime sources remain byte-identical to beta24. Native Windows rerun required.


## v3.1.0-beta24 — 2026-10-05

- Include the failed settings-file destination explicitly in recovery diagnostics,
  retaining the original exception/stack as the inner cause. Avoid reliance on the
  operating system/framework exception message containing the full path.
- Keep the existing failed-disk-rollback assertion and add a pathless/localized-error
  test, including combined disk/runtime errors and runtime-only failure. App-state: 26.
- Keep the divergence notice and actual rollback/save/worker behavior unchanged.
  Core processing, runtime I/O and MainForm/UI production code are unchanged.
- Record the supplied beta23 Windows Phase 4 result (24 passed, one diagnostic-path
  failure) and local beta24 verification. Native Windows rerun remains required.


## v3.1.0-beta23 — 2026-10-05

- Extend metadata filtering with Unicode letters, decimal digits and combining marks
  from other scripts. Preserve Yoruba accents and Ewe/CJK/Indic/Arabic/Hebrew text with
  Translit On in Unicode; retain the existing symbol/emoji policy and control cleanup.
- Add 44 explicit ASCII approximations for additional Latin letters, including Ewe,
  Hausa and schwa. Keep all inherited ASCII replacements and their existing casing.
- Add common extended Cyrillic letters and composed-letter fallback for additional
  Cyrillic/polytonic Greek forms, while keeping existing mappings/digraphs unchanged.
- Fit at complete base-letter/combining-mark boundaries under the existing UTF-16 budget;
  protect common Indic virama/joiner boundaries. Retain meaningful Unicode joiners and
  recognize supplementary-plane letters/digits. Keep Latin invisible-joiner cleanup.
- Add 178 processing assertions (528 total), 1,056 multilingual spelling/mode/form/order/
  target runs and 3,680 boundary compositions. All inherited 350 assertions remain.
- Verify six output fields for 1,584 unaffected baseline configurations against beta22:
  identical results. Check 56 multilingual UTF-8 input cases via the unmodified reader
  and actual multilingual Unicode/ASCII WinForms renders. Runtime/UI production code
  is unchanged; native Windows/encoder/font verification remains pending.


## v3.1.0-beta22 — 2026-10-05

- Convert full artist/title fields before applying the visible RT length budget. Build
  RT and RT+ from the same bounded fields; remove tags/separators for fields made empty
  by conversion. Keep target control tags and escaped syntax outside that budget.
- Retain Vietnamese vowel/tone letters from Latin Extended Additional with Translit
  enabled. Unicode preserves their diacritics; ASCII-safe retains the base letters.
- Keep accent/tone differences significant in title/artist/guest identity comparisons;
  normalize equivalent NFC/NFD spellings together without stripping meaningful marks.
- Add 102 processing assertions, including a 5,600-case RT/RT+ composition matrix, both
  targets/orders, the reproduced 64/65 overflow, empty fields, 90 Vietnamese vowel/tone
  combinations, decomposed input, casing and accent-sensitive identity regressions.
- Add actual Vietnamese Unicode/ASCII main-screen captures. Retain beta21 asynchronous
  commits, persistent recovery errors, diagnostics and one-click Settings/confirmed Exit.


## v3.1.0-beta21 — 2026-10-05

- Run F10 Save & exit through the shared guarded background commit path; keep the UI
  responsive and reject duplicate actions until the accepted save finishes.
- Show visible progress for slower saves, keep ordinary warnings for eight seconds
  and log complete save exceptions. Keep failed drafts/quick choices available for retry.
- Report failed settings/runtime rollback explicitly in an owned acknowledgement dialog;
  retain and log both the original and secondary failures. Wrap the complete recovery notice.
- Open F10 Settings or the Exit confirmation with one click from every quick popup,
  retaining their existing hover frames.
- Remove unused grid/notice truncation helpers, obsolete popup Help progress code,
  the unused country-token test helper and ISO3 cache; retain required ISO2 data.
- Centralize UI/assembly version information and footer/rule indexes/counts. Keep
  processing, settings defaults/schema, output names/encodings and RT+ formats compatible.
- Add deterministic rollback-failure and actual WinForms asynchronous-commit regressions;
  update release scripts, documentation and native Windows verification checklist.

## v3.1.0-beta20 — 2026-10-05

- Add Left/Right switching between the four status-bar quick menus, with wrapping;
  keep Up/Down inside the choices. Tab/Shift+Tab dismisses and advances footer focus
  without activating Settings or Exit. Accepted saves complete before navigation.
- Switch between quick popups with one click, retaining current-field dismissal,
  hover/tooltips, committed check marks and the immediately saved Rules changes.
- Fit picker paths, input filenames and menu labels to actual font measurements;
  preserve Unicode text-element boundaries and reserve the value/check column gap.
- Retain beta19 headerless popup geometry, contextual tooltips and F10 transactions.
- Update version labels, release scripts/docs and the actual WinForms UI probe.


## v3.1.0-beta19 — 2026-10-05

- Remove titles, keyboard legends, header separators and close buttons from all four
  status-bar quick popups, including Rules. Keep contextual footer tooltips.
- Size each popup to measured option labels/check marks and use equal ten-pixel top
  and bottom padding. Render, hit-test and scroll against the same compact geometry.
- Remove the former header/close hit areas so every choice remains clickable across
  its full row. Keep Esc/outside/focus-loss dismissal and immediate saving unchanged.
- Keep transient messages within the main client when anchored on narrower popups;
  fit their text to the actual rendered width, including substitute fonts.
- Retain beta18 tooltips, smaller About, F10 headers/dragging and Settings/Exit frames.
- Update version labels, scripts, documentation and actual WinForms UI probe.

## v3.1.0-beta18 — 2026-10-05

- Include all rc1 settings recovery, publisher lifecycle/retry and F10 keyboard fixes.
- Show full-value tooltips only for actual rendered truncation in LOCATIONS, FILES and
  CONTENT, including INPUT. Match hover bounds to visible values and update tips as
  live metadata changes. Retain output diagnostics even when the folder path fits.
- Use concise state-aware Translit tooltips: Greek/Cyrillic → Latin in Unicode;
  Required in ASCII-safe mode when forced.
- Reduce About to a 36-column minimum; preserve font-measured header fitting.
- Remove hover feedback from non-draggable anchored quick-popup headers; retain close
  button/choice feedback, draggable F10 headers and Settings/Exit hover frames.
- Retain shared initial child placement and opaque popups without main-screen dimming.
- Update the actual WinForms UI probe, version labels, scripts and release documentation.
  Native Windows verification remains required; numeric versions remain 3.1.0.0.

## v3.1.0-rc1 — 2026-10-05

- Recover empty/relative/malformed active custom output paths at settings load with LastLoadWarning;
  preserve other settings and the existing JSON. Valid offline destinations are retained without I/O.
  Shared path normalization also rejects Windows drive-relative/root-relative custom destinations.
- Retire rejected publishers before rollback and superseded publishers after successful switching.
  Drop queued work without clearing destination files. Preserve an unswitched output health monitor.
- Let changed payloads bypass output retry backoff, also when queued behind an older failing write.
  Identical payloads retain bounded two-second retries and all publication remains single-writer.
- Support Space alongside Enter for F10 rule toggles and setting choices. Preserve transactional
  drafts, explicit Enter for Save & exit/Restore defaults/exit confirmation and literal editor spaces.
- Add five Runtime regressions (48 total), four App-state regressions (24 total), one overlay policy
  regression (33 total), and actual WinForms keyboard/transaction checks in the rc1 UI probe.
  Replace a stale fixed-cell footer assertion with renderer coverage in the existing 72-case probe.
- Update source-map title and add .gitattributes; normalize C# repository text to LF and CMD to CRLF.
  Document downgrade behavior and retain beta17 layout, numeric 3.1.0.0 and current stable v3.0.4.
- Record local Mono/native-source and POSIX-only verification separately. Windows 10/11 with
  .NET Framework 4.8, native atomic saving, ACL/sharing/network behavior and font/DPI remain open.


## v3.1.0-beta17 — 2026-10-04

- Size status fields to their current complete label/value/chevron, eliminating reserved gaps.
  Following status items and their clickable bounds reflow together when a value changes.
- Use equal nine-pixel margins on both sides of every pipe. Keep Settings/Exit at their fixed
  lower-right positions, with remaining width between the complete status group and commands.
- Retain full values and select one stable fitting font from the longest configuration.
  Labels, client dimensions, shortcut order, popup choices and saving behavior are unchanged.
- Expand rendered UI verification for equal pipe margins, current hit targets, compact reflow
  and fixed command positions across 72 configurations. Update release documentation.
- Retain shared child placement and all runtime, quick/F10 and mouse/keyboard behavior.


## v3.1.0-beta16 — 2026-10-04

- Attached each status chevron directly to its actual value, keeping label/value/arrow together.
  Spare width now follows the complete group instead of separating short values from their arrows.
- Retained fixed label starts, separators, hover/focus bounds, click targets and popup anchors.
  Changes to one field do not move the other fields. Full values and existing font fitting remain.
- Expanded rendered UI checks for inline chevron pixels, clickable positions and absence of a
  detached old-endpoint arrow across all 72 settings configurations. Updated release documentation.
- Retained beta15 child placement and all runtime, quick/F10 settings and mouse/keyboard behavior.


## v3.1.0-beta15 — 2026-10-04

- Reserved each of the four status fields' longest value, keeping labels, arrows, separators,
  hover/focus areas, click targets and popup anchors fixed across all settings changes.
  Labels and values remain adjacent; no extra abbreviations or client-width changes are needed.
- Added generic initial child placement that separates nearly coinciding corresponding edges
  from the immediate parent. The same rule applies to About and every nested menu/dialog.
- Retained content dimensions and normal centering when already clear; chose the nearest fitting
  offset with boundary-aware direction and best available clearance when space is limited.
- Applied separation only during initial placement. Roots/standalone quick popups keep their
  existing placement, and initialized/hand-dragged child positions remain persistent.
- Added three geometry regressions and expanded native UI reproduction for stable field bounds,
  About outlines, repeated paints and actual grandchild dragging. Updated release documentation.
- Retained all beta14 processing, fast commits, immediate Rules editing, F10 draft checks,
  output health/recovery, forced transliteration and mouse/keyboard focus behavior.


## v3.1.0-beta14 — 2026-10-04

- Kept the Rules quick popup open after each immediate atomic save. Check marks refresh in place,
  selection/scroll remains and dismissal retains successful changes. Other quick choices still close.
- Kept old committed checks on save failure, including when earlier edits succeeded. Focus loss
  during an accepted save dismisses only after it completes. No Apply button is introduced.
- Changed F10 Sanitizer rules from [On]/[Off] to matching check marks reflecting the draft. Reduced
  minimum width from 64 to 48 columns and measured the full header, longest label and check margin.
- Reordered footer fields to Rules | Chars | Translit | Case, including choices, tooltips, keyboard
  order and forced-transliteration gating. Chars and its dependent Translit are now adjacent.
- Removed persistent mouse-origin footer focus/highlights for all four status links and Settings/Exit.
  Actual pointer hover is refreshed after dismissal; Tab/Enter retains a separate dotted focus cue.
- Removed idle-worker polling delay from live settings switches by waking the existing monitor event
  and skipping stamp lookup after stop. Normal 1000 ms polling, atomic persistence, rollback,
  publisher drain, stop timeout and single-worker/writer safeguards remain unchanged.
- Added stop-wake and successive-commit regressions, expanded the optional native UI probe and
  updated release documentation. Defaults, schema, sanitizer Core and output formats are unchanged.
- Retained v3.1.0 numbering for compatible feature additions; stable remains v3.0.4.


## v3.1.0-beta13 — 2026-10-04

- Added independent background output-directory availability monitoring, confirmed disconnects,
  bounded passive probes and active mapped/UNC reconnect backoff. Quiet paths are monitored too.
- Shared input/output paths reuse input availability; OUTPUT DIR now shows OFFLINE consistently.
  Separate destinations start CHECKING. WRITE FAILED remains an independent publication result.
- Recovery republishes the newest desired payload without requiring a new input event. Empty
  output intent is retained, so reconnect cannot resurrect metadata already cleared by the runtime.
- Replaced status-link menu stacks with anchored standalone quick-choice popups, committed check
  marks and immediate atomic save/activation. One successful action closes each of the four popups.
- Rules toggles one of twelve rules per popup action; multiple changes/Restore defaults remain in
  F10. Translit explains forced On in ASCII-safe and disables Off without losing the Unicode preference.
- Kept Esc/X/outside dismissal before selection, keyboard footer order and F10 draft transactions.
  Failed quick saves retain active settings and the popup; asynchronous saving keeps UI responsive.
- Allowed unrelated setting changes with unchanged offline input/output paths. Changed paths still
  validate access. Renamed LOCATION to LOCATIONS; kept CONTENT and the existing one-row footer/layout.
- Corrected the inherited About version-display constant; title/About/informational version is beta13.
- Added five application-state regressions and one publisher recovery regression. Updated the optional
  WinForms probe for direct commits, save failures, forced state, anchoring, dismissal and all 72 footer
  combinations. Core/defaults/output formats/schema remain unchanged; Windows verification remains open.


## v3.1.0-beta12 — 2026-10-04

- Added Output settings > Output folder with Same as input folder (default) and Choose folder….
  Follow mode moves with the input folder; a custom destination stays fixed and is remembered.
- Added compatible OutputUseInputFolder/OutputFolder settings. Old JSON keeps its existing paths.
  Renamed the input menu/picker label to Input folder while retaining the WorkDir JSON key.
- Routed all six outputs and shutdown cleanup to the effective destination. Input monitoring remains
  at the input file. Input read/list access and output write access are checked independently.
- Added a single background writer for separate destinations, newest-payload coalescing, bounded
  switch/shutdown waiting and independent output errors/retries. No silent fallback destination.
- Preserved atomic Save & exit, save-error protection/rollback and stale-output safety. A destination-
  only change republishes current metadata even when the current input timestamp is old.
- Added INPUT DIR and OUTPUT DIR to LOCATION, full-path/error tooltips and actual-font width fitting
  for main values/warnings. The client is 999 by 500; the single status row and right-side actions remain.
- Added six runtime and four application-state regressions, plus picker draft/cancel UI checks.
  Updated output submenu indices so status links and forced-transliteration handling remain correct.
- Core is unchanged. Local Mono results and their platform limitations are recorded separately from
  required Windows verification. Updated versions, release docs/checklist and source manifest.

## v3.1.0-beta11 — 2026-10-04

- Replaced the two-row SETTINGS block with one unnamed status row: Rules, Chars, Case, Translit.
  Removed RT+ target from the status bar while retaining its Output settings menu.
- Shortened status labels without abbreviation periods; retained full values without brackets/colons.
  Compact graphical pipes, muted labels and bright values separate the four fields.
- Added direct links to existing submenus, chevrons, hover highlights, hand cursors and full-name
  tooltips, plus Tab/Shift+Tab and Enter/Space navigation for fields and global commands.
- Preserved the draft/Save & exit transaction. The forced ASCII-safe transliteration link opens
  its disabled Output settings row with an explanation instead of bypassing the restriction.
- Kept Settings/Exit side by side at the lower right. Reduced main height by one 20-pixel row to
  999 by 480 pixels; content positions, width and the full bottom margin remain unchanged.
- Retained cached status-font fitting and measured shortcut/label spacing for wider action fonts.
- Updated existing layout assertions and checked 72 combinations, field/action hitboxes, fonts,
  actual navigation/input and draft/cancel/save-error behavior. Native Windows checks remain required.
- Updated version stamps, current docs, release notes, checklist and source manifest. Processing,
  persistence schema, menu choices and earlier fixes remain unchanged.


## v3.1.0-beta10 — 2026-10-03

- Compressed both SETTINGS status rows using measured text widths and compact pipe spacing.
  Preserved their order and the main section/content-column alignment; removed wide fixed slots.
- Shortened only main-screen labels: Sanitizer rules → Sanitizer, Character set → Characters.
  Menu labels, complete status values and RT+ target names are retained.
- Separated Settings/Exit into a fixed right-side action zone behind a thin vertical line spanning
  both status rows. No setting shares their zone. Main client size and bottom margin are unchanged.
- Added cached status-font fitting for wider substitutes. Fitting fonts keep their size, and
  action/menu/section text is unchanged. Status text stays at one size across all configurations.
- Updated the existing geometry/fit assertions and checked 72 configuration combinations, fitting/
  wider baseline fonts, action hitboxes and inherited menu/draft behavior.
- Updated version stamps, current docs, release notes and checklist. Processing, saved settings,
  status semantics and transaction/dismissal behavior remain unchanged from beta9.

## v3.1.0-beta9 — 2026-10-03

- Harmonized SETTINGS with FILES/CONTENT: the section name sits beside the first status row,
  and both rows begin their content in the same field-label column as the other main blocks.
- Replaced flowing status positions with three fixed group columns. Paired rows align, and two
  subdued pipe separators mark the same boundaries on both rows. Labels stay beside their values.
- Aligned RT+ with the Settings/Exit action group below it. Action hover/click regions follow
  the new row; full labels, status values and product names are retained.
- Removed the separate title row and restored the 500-pixel main client height; width and full
  bottom breathing space are retained. Updated existing geometry/fit regressions.
- Verified all 72 settings combinations fit before their separators under the wider substitute
  font, plus menu navigation, draft/cancel semantics and the relocated action hitboxes.
- Updated version stamps, current docs, release notes and checklist. Processing, saved settings,
  status semantics and dialog-dismissal behavior remain unchanged from beta8.

## v3.1.0-beta8 — 2026-10-03

- Added a SETTINGS heading and two compact rows of committed configuration values. The first
  row follows Sanitizer rules → Character set → RT+; the second groups Letter case and
  Transliteration. Labels stay close to their values, with consistent spacing between groups.
- Removed the lone pipe; kept F10 Settings and Alt+F4 Exit together on the right of the second row.
  The main window keeps its width and gains one 20-pixel row, preserving a full bottom margin.
- Replaced the cryptic [On*] with [Forced on] for ASCII-safe transliteration in the main overview
  and Output settings. Original/All caps/Capitalize words and the full RT+ target names are shown.
- Retained explicit dismissal of text-entry dialogs, root Settings and exit confirmation, and
  outside-click back navigation for choice submenus; documented the existing behavior.
- Extended existing footer/snapshot and geometry assertions. Supplementary UI verification covers
  72 configuration combinations, full labels, action hitboxes, draft isolation and input dismissal.
- Updated version stamps, current documentation, release notes and checklist. Core, Runtime,
  stored settings, defaults, output formats and Save & exit/rollback semantics are unchanged.

## v3.1.0-beta7 — 2026-10-03

- Added a separator before Restore defaults in Sanitizer rules, with the same gutter treatment
  as Save & exit and preserved bottom breathing space. Mouse hit testing uses the rendered row
  rectangles; the separator cannot be selected and the full Restore defaults row remains clickable.
- Harmonized menu options/values with sentence case: Original, All caps, Capitalize words,
  Unicode, ASCII-safe, On/Off, artist/title order and product names. Technical codes remain uppercase.
  Exit/Cancel buttons follow the same style; main-screen section/status styling is unchanged.
- Simplified the footer to Sanitizer rules [Standard]/[Custom] and the fixed action shortcuts.
  Removed Delimiter/RT+ summaries and measured label/value placement for compact grouping.
  The status describes committed rules, remains neutral for Custom, and never displays an OFF count.
- Extended complete-header font measurement to the five small choice menus.
- Updated existing footer, geometry and live-setting regression assertions. Test totals remain
  Core 248, Runtime 35, App-state 10 and Settings/overlay 29.
- Updated version stamps, current documentation, release notes and checklist. Processing,
  serialized setting keys, defaults, outputs and Save & exit/rollback semantics are unchanged.

## v3.1.0-beta6 — 2026-10-03

- Made the root Settings menu navigation only, removing every root value summary.
- Renamed Input source to Input settings and moved Playout delimiter into that submenu after
  Working directory and Input file. The root now has five rows.
- Narrowed the root window from 56 to a minimum of 48 columns and reduced its height by one row.
  Runtime font measurement preserves the complete Up/Down, Enter and Esc header plus side margins.
- Simplified the footer to readable Sanitizer and Delimiter labels and full RT+ target names.
  Removed the OFF counter and composite OUT code; custom delimiters display their actual value.
  F10 Settings / ALT+F4 Exit positions remain fixed.
- Updated menu/footer regression assertions and added header/footer-fit coverage (28 -> 29 tests).
- Refreshed current documentation, version stamps, release notes and the release checklist.
  Processing, persisted settings, outputs and the beta5 sanitizer fixes are unchanged.

## v3.1.0-beta5 — 2026-10-02

- Fixed ALL CAPS sharp-s conversion: `ß` is expanded to `SS` before uppercasing, keeping Unicode,
  ASCII-safe, standalone and RT/RT+ output consistent; ORIGINAL behavior is unchanged.
- Added a shared disabled-rule count: Settings shows `[CUSTOM: N OFF]`, and the footer shows
  `[N OFF]` while all-ON remains `[STANDARD]` / `[STD]`. Snapshot cloning retains the count.
- Clarified **Technical audio tags** as **Audio, source & release tags**, documenting the broader
  source/software/ripper/release cleanup; the persisted option name remains unchanged.
- Renamed the semantic cleanup helpers to `StripTechnicalNoiseTags` and `IsTechnicalNoiseTagToken`.
- Added 68 Core regression checks for all-OFF rules, mixed toggles, fixed safety protections,
  the broader technical-tag categories, sharp-s and Capitalize Words examples (180 -> 248).
- Added disabled-count/menu-width regression coverage (Settings/overlay: 27 -> 28) and expanded
  existing footer-state and Runtime default tests.
- Corrected menu ordering and beta3/beta4 release history in the active documentation.

## v3.1.0-beta4 — 2026-10-02

- Placed **Playout delimiter** immediately after **Input source**, so Settings follows
  source -> parse -> sanitize -> output: Input source, Playout delimiter, Sanitizer rules,
  Output settings, About, Save & exit.
- Updated the root-order regression expectation; processing and persistence are unchanged.

## v3.1.0-beta3 — 2026-10-02

- Renamed **Text output** to **Output settings** and moved **RT+ output target** into that submenu.
- Reduced the root Settings menu to Input source, Sanitizer rules, Output settings, Playout delimiter, About, and Save & exit.
- Changed the Input source root-row summary from filename-only to the effective combined input path, with left-side ellipsis that keeps the filename visible on long paths.
- Changed the compact footer category label from **TXT** to **OUT** while retaining RT+ as a separate compact state and preserving the fixed F10/ALT+F4 command zone.
- Removed the obsolete `_hoverActionC` state left behind after beta2 removed the third Working-directory-browser action, eliminating the beta2 CS0414 build warning.
- Added/updated regression coverage for the six-row root Settings geometry, seven-row Output settings submenu, and path-tail input-source formatting.

## v3.1.0-beta2 — 2026-10-02

- Grouped Working directory and Input file under a single Input source menu.
- Removed the duplicate Input file shortcut from the Working directory browser.
- Reworked the main footer to compact SAN / TXT / DEL / RT+ status summaries with a fixed right-side command zone.
- Preserved the beta1 configurable sanitizer/text-output behavior and v3.0.4-compatible defaults.
- Added compact-footer snapshot regression coverage and updated Settings navigation tests.

## v3.1.0-beta1 — 2026-10-02

### Configurable sanitizer rules

- Added a **Sanitizer rules** Settings submenu with twelve independently toggleable cleanup groups.
- All sanitizer rules default to ON, preserving v3.0.4 processing behavior after upgrade.
- Added **Restore defaults** to re-enable all sanitizer rule groups.
- Technical safety normalization, validation and fail-closed behavior remain always active.

### Text output

- Added a **Text output** Settings submenu grouping Prefix text, Connector text, Artist/title order,
  Character set, Transliteration EL/CYR and Letter case.
- Added **ORIGINAL**, **ALL CAPS** and preservation-first **CAPITALIZE WORDS** output case modes.
- Renamed the presentation of the previous ASCII-safe switch to the clearer Character set choice
  **UNICODE / ASCII-SAFE**; existing ASCII/transliteration semantics are unchanged.
- Added Input file directly to the Settings root menu.

### Compatibility and testing

- Existing v3.0.4 settings migrate with all new sanitizer rules ON and letter case ORIGINAL.
- Settings schema remains additive; output filenames, delimiter behavior and RT+ target formats are unchanged.
- Expanded Core self-tests from 158 to 180 cases, Runtime tests from 34 to 35, and Settings/overlay
  tests from 26 to 27.
- This is a beta build intended for Windows/.NET Framework 4.8 verification before a stable v3.1.0 release.

## v3.0.4 — 2026-10-01

Sanitizer correctness and robustness maintenance release.

### Changes

- Hardened version/remaster/whitelist/soundtrack/live-location tail stripping so destructive
  separated-tail cleanup starts at the rightmost eligible separated segment and does not cross an
  earlier semantic `:` / `-` boundary. Examples such as `Star Wars: Episode IV - Radio Edit`,
  `Mission: Impossible Theme - Extended Version`, and classical movement titles now retain their
  meaningful prefix while still removing the technical tail. The rightmost-eligible scan now continues
  across separators that belong inside the technical suffix itself (for example quoted movie names or
  live-location qualifiers), and stacked technical tails remain removable.
- Require visible separation around destructive dash suffixes, preserving natural hyphenated text
  such as `Re-Live It` and `Non-Studio Jam` while still removing `Song - Live` / `Song - Studio Version`.
- Made country cleanup preservation-first: ambiguous ISO-like prefixes such as `DJ`, `MC`, `TV`
  and `CAN` no longer trigger destructive cleanup. Clear full-country dash prefixes tolerate missing
  whitespace on either side of the dash, and a small explicit whitelist handles unambiguous tight
  multi-word prefixes such as `The Netherlands-Walk Along` without reintroducing `China-Town` /
  `Cuba-Libre` false positives. Artist-only trailing uppercase bracketed ISO2 region tags such as
  `Diesel (NL)` are stripped again; equivalent title suffixes remain preserved. Bracketed full-country
  prefixes also tolerate a missing post-bracket space without making ISO-like bracket codes destructive.
- Set the process-wide regex default timeout at the start of `Program.Main`, use explicit timeouts in
  the high-risk tail/country paths, and make `ComposeOutputs` fail closed to an empty payload on
  `RegexMatchTimeoutException`.
- Made HTML entity decoding single-pass by decoding `&amp;` last; decoded invisible controls such as
  soft hyphen are removed after decoding.
- Normalize field/custom text to Unicode NFC before filtering so canonically equivalent NFD input
  such as `Jose\u0301` retains the same accented character as NFC `José`.
- Apply apostrophe-suffix case normalization to the canonical artist/title parts instead of only the
  visible RT string, keeping standalone, RT and RT+ text consistent.
- Tightened degree/temperature and omega/unit replacement boundaries and made compilation cleanup
  conservative enough to preserve natural text such as `Love Song (Best of Friends)`, `Best of Both Worlds`
  and `The Best of Both Worlds`, while retaining clear qualified compilation markers such as
  `Greatest Hits 80s`, `The Essential Michael Jackson` and `The Best of Queen`.
- Refined tight-separator handling so strong metadata markers such as `Deluxe Edition`, `Explicit`
  and `Theme from ...` remain supported without stripping ambiguous natural forms such as
  `Squeaky-Clean` or `Hero-Epic Movie Soundtrack`.
- Tightened the Core raw-metadata safety limit from 4096 to 1024 characters. The 64-KiB file-level
  guard remains unchanged; the lower Core limit bounds work before regex-heavy sanitizer processing.
- Expanded Core self-tests from 73 to 158 cases with positive and negative regressions for all of the
  above preservation/robustness changes.

### Compatibility

- Settings schema, input/output filenames, delimiter behavior and RT+ target formats are unchanged.
- Clear full-country metadata forms such as `Belgium - Song Title`, `Belgium- Song Title`, and
  whitelisted tight multi-word forms such as `The Netherlands-Walk Along` remain supported.
- Ambiguous country-code-only prefix/title cleanup is intentionally non-destructive; artist-only
  uppercase bracketed ISO2 region suffixes remain supported as a narrowly scoped cleanup rule.
- No migration is required from v3.0.0 through v3.0.3.

## v3.0.3 — 2026-09-30

Small responsiveness and UI-legibility maintenance release.

### Changes

- Reduced the special empty-title / artist-only split-write quiet period from 600 ms to 100 ms.
  Very short partial writes are still absorbed, while a genuine `Artist<delimiter>` record no longer
  incurs a visibly long delay. If a title arrives later, the normal hybrid input monitor detects the
  file update and republishes the completed metadata.
- Kept the existing round status-leader dots but doubled their centre-to-centre pitch to the
  Colour Lab-selected 200%, making long leaders less separator-like without changing dot shape,
  thickness or semantic colour.
- Precomputes the fixed 200% leader dash pattern once instead of recalculating it and allocating a
  new dash array on every leader repaint. Visual output is unchanged.
- Replaced the quantized LAST UPDATE colour ramp with explicit thresholds: healthy below 5 minutes,
  warning from 5:00 through 14:59, and error from 15:00 onward. This makes
  `HealthCriticalAtSeconds = 900` actually become critical at 15 minutes.
- Increased `TextMuted` from RGB `105/105/105` to `125/125/125`.
- Increased separator-line RGB from `82/82/82` to `100/100/100`.
- Updated the Colour Lab defaults to the v3.0.3 palette and 200% round-dot spacing, and corrected
  its `WORKING DIR` label so the label uses the same healthy green as the path value.

### Compatibility

- Settings schema, input/output filenames, delimiter behaviour and RT+ target formats are unchanged.
- No migration is required from v3.0.0, v3.0.1 or v3.0.2.

## v3.0.2 — 2026-09-29

- Release verification: extracted `AppLog` into its own source file and added it to every direct-csc application/self-test build, so Phase 4-7 harnesses compile with the v3.0.2 logging calls.

Runtime/input hardening maintenance release.

### Changes

- Fixed the text-decoding fallback: UTF-8 is now decoded strictly so invalid byte sequences actually
  fall back to the Windows default code page; U+FFFD replacement characters are stripped defensively.
- Metadata containing more than one configured delimiter now fails closed as `INVALID` instead of
  being concatenated into corrupt artist/title output.
- Added two layers of pathological-input protection: input files above 64 KiB are rejected before a
  full read, raw metadata above 4096 characters is rejected by the processing engine, the static
  regex cache is enlarged, and sanitizer regex operations receive a default match timeout.
- Hardened RT+ output against formatter/tag injection. Stereo Tool values now escape its documented
  formatted-text control characters (`<`, `>`, `|`, `:`, `/`, `\`); Magic RDS 4 values cannot inject
  additional angle-bracket RT+ tags.
- Recoverable exceptions while processing one metadata update no longer terminate the runtime worker.
  The update fails closed, outputs are cleared, the incident is logged, and the next update is processed.
- Added application diagnostics in `%LOCALAPPDATA%\Sanitize NowPlaying\SanitizeNowPlaying.log` with
  simple size rotation; fatal worker/UI/startup failures and corrupt-settings fallback are recorded.
- Corrupt settings still fall back to safe defaults for compatibility, but the fallback is no longer
  diagnostically silent.
- Removed reflection from custom-text validation. The UI now calls the same public Core conversion
  path directly and delegates normalization to Core, eliminating duplicated normalization logic.
- Removed Ctrl+C as an Exit shortcut, changed the footer hint to Alt+F4, and added a rounded in-app
  modal exit confirmation with explicit `EXIT` / `CANCEL` actions; Cancel is the safe default because
  normal shutdown clears all output files, including files that pre-date the current session. The confirmation uses the neutral UI palette rather
  than the warning colour, because normal application shutdown is not an error/degraded state.
- Expanded Core and Runtime regression tests for multi-delimiter input, oversized input, replacement
  characters, legacy/default-codepage decoding, RT+ injection/escaping and corrupt-settings diagnostics.
- Clarified the main-screen invalid-input status from `INVALID` to `INVALID DATA`, so it describes
  malformed metadata content rather than implying that the input file itself is invalid.
- Corrected the v2.1.8 parity smoke corpus so the intentional v3.0.2 multi-delimiter fail-closed
  divergence is excluded from the suite of *unaffected* compatibility cases.
- Cleaned up repository presentation without changing runtime behavior: obsolete phase scripts,
  phase reports and superseded release artifacts are archived under `docs/history/`, while the root
  retains only the active release workflow and its required helper scripts.

### Compatibility

- Settings schema and output filenames are unchanged.
- The no-delimiter title-only fallback remains supported.
- Inputs with multiple configured delimiters now intentionally fail closed rather than following the
  legacy concatenate-as-title behaviour.
- No migration is required from v3.0.0 or v3.0.1.

## v3.0.1 — 2026-09-28

Sanitizer safety/hardening maintenance release.

### Changes

- Hardened adjacent comma-prefix artist deduplication so destructive comparisons keep meaningful
  parenthetical and `of/from` qualifiers. The intended `Steve Harley, Steve Harley & Cockney Rebel`
  cleanup remains supported while distinct same-name credits are preserved.
- Applied the same strict-identity rule to bracketed artist-prefix deduplication.
- `Mono` / `Stereo` are now removed only when clearly marked as technical suffixes (for example
  `(Mono)`, `[Stereo]`, `- Stereo`, `/ Mono` or `| Stereo`), preserving legitimate titles such as
  `Life in Mono`.
- Duplicate-title cleanup now requires the complete normalized title parts to match and no longer
  discards arbitrary trailing bracket qualifiers; e.g. `Song (Part 1) - Song (Part 2)` is preserved.
- Apostrophe case cleanup no longer damages intentionally all-caps text such as `DON'T` or `O'JAYS`,
  while still correcting accidental mixed-case suffixes such as `John'S`.
- Updated the processing-engine description: v2.1.8 remains the compatibility baseline, but v3.0.1
  intentionally contains conservative safety hardening and therefore no longer claims universal
  byte-for-byte processing parity with the legacy implementation.
- Expanded the processing-engine self-test suite with v3.0.1 regression cases and clarified the
  legacy parity smoke test as coverage for unaffected baseline cases.

### Compatibility

- Settings schema, output filenames, delimiter behaviour, RT+ targets and runtime/UI behaviour are
  unchanged from v3.0.0.
- No migration is required from v3.0.0.

## v3.0.0 — 2026-09-27

First public release of the C# / WinForms generation.

### Major changes from v2.1.8

- Complete rewrite from PowerShell/conhost to C# / .NET Framework 4.8 WinForms.
- Standalone graphical application; no PowerShell or console host required at runtime.
- New v3 application icon and product identity.
- Vendor-neutral product name `Sanitize NowPlaying`; platform names are used only for target-specific integration.
- Fixed delimiter-menu column alignment so custom delimiters of 1–5 characters align consistently.
- Restored human-readable multi-line settings JSON formatting (one setting per line).
- Preserves the v2.1.8 sanitizing/output contract with exact parity regression coverage.
- Transactional in-app Settings UI with nested overlays and custom text editors, a visually separated `Save & exit` commit action, fixed right-aligned value columns, a more compact prefix selector, harmonized full-row bottom padding, and dedicated separator gutters that never share a text baseline.
- Settings, child, grandchild and deeper active overlays can all be repositioned by dragging their header.
- Simplified overlay keyboard UX: Enter confirms, Esc goes back/cancels, while Left/Right are reserved for text-caret movement only.
- Added a subtle draggable-header hover highlight with matching text brightening across menu overlays and an in-app `About` child overlay showing product/version/copyright information in the standard content colour.
- Fixed compact choice-overlay header overflow and added defensive header clipping.
- Compact 25-row main UI with semantic health/status colours and regression-checked row mapping.
- First-run Working Directory setup and internal folder/volume picker.
- Configurable input filename (default `nowplaying.txt`) integrated into the Working Directory picker and first-run setup, including existing-file selection, manual entry, clearer semantic sections, bright standalone folder actions, supported plain-text extension filtering (`.txt`/`.log`/`.dat`/extensionless), Windows filename validation and output-file collision protection.
- Configurable RT+ output target for `nowplaying_rtplus.txt`: Stereo Tool remains the backward-compatible default, with Magic RDS 4 inline `Item.Artist` / `Item.Title` tag output as an alternative.
- Network Working Directory availability/status handling and automatic reconnect.
- Persisted mapped/UNC Working Directories are preserved when temporarily offline at startup; the app starts in OFFLINE/reconnecting state instead of silently switching to a local fallback or reopening first-run setup.
- Settings commits are fail-safe: an atomic settings-save failure leaves the existing runtime running, while runtime-switch failures roll the persisted settings back to the previous configuration.
- Runtime worker shutdown now verifies that the old worker actually stopped before a replacement can start, preventing overlapping workers after delayed I/O.
- Artist-only split-write handling now requires a meaningful quiet period before accepting an empty-title record, covering playout writers that complete the title hundreds of milliseconds later.
- Six individually atomic UTF-8/no-BOM output files.
- Exact failed-payload output retry and LastGood update protection.
- Fatal worker errors fail safe by clearing derived UI content and attempting to clear all six output files.
- Explicit EMPTY / MISSING / EXPIRED / UNAVAILABLE / INVALID runtime states.
- Consistent warning/status colour policy and right-side status leaders.
- Accelerated regression/stress suite, including fuzzing, concurrent file/settings access,
  partial writes, watcher storms, locks, lifecycle cycles and memory plateau checks.
- Release packaging now verifies/builds by default, checks staging errors, and never relies on a stale prebuilt EXE.
- Cleaned obsolete private helpers, synchronized all no-sparkle icon assets, removed stray editor backup files, normalized legacy `.csproj` import ordering, and added source-tree hygiene rules.

### Compatibility

- Existing `Sanitize-NowPlaying.settings.json` format retained.
- Output filenames retained.
- Processing parity reference remains PowerShell v2.1.8.
- AnyCPU build: normally 64-bit on 64-bit Windows and 32-bit on 32-bit Windows.

### Known limitation

Mapped-network recovery may take several seconds after Windows reports that connectivity has
returned. The application deliberately remains OFFLINE until the runtime watcher/input path has
recovered safely.
