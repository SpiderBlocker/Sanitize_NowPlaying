# Changelog

## v3.0.4 — 2026-10-01

Sanitizer correctness and robustness maintenance release.

### Changes

- Hardened version/remaster/whitelist/soundtrack/live-location tail stripping so destructive
  separated-tail cleanup starts at the rightmost eligible separated segment and does not cross an
  earlier semantic `:` / `-` boundary. Examples such as `Star Wars: Episode IV - Radio Edit`,
  `Mission: Impossible Theme - Extended Version`, and classical movement titles now retain their
  meaningful prefix while still removing the technical tail. The rightmost-eligible scan now continues
  across separators that belong inside the technical suffix itself (for example quoted movie names or
  live-location qualifiers), and stacked technical tails remain removable.
- Require visible separation around destructive dash suffixes, preserving natural hyphenated text
  such as `Re-Live It` and `Non-Studio Jam` while still removing `Song - Live` / `Song - Studio Version`.
- Made country cleanup preservation-first: ambiguous ISO-like prefixes such as `DJ`, `MC`, `TV`
  and `CAN` no longer trigger destructive cleanup. Clear full-country dash prefixes tolerate missing
  whitespace on either side of the dash, and a small explicit whitelist handles unambiguous tight
  multi-word prefixes such as `The Netherlands-Walk Along` without reintroducing `China-Town` /
  `Cuba-Libre` false positives. Artist-only trailing uppercase bracketed ISO2 region tags such as
  `Diesel (NL)` are stripped again; equivalent title suffixes remain preserved. Bracketed full-country
  prefixes also tolerate a missing post-bracket space without making ISO-like bracket codes destructive.
- Set the process-wide regex default timeout at the start of `Program.Main`, use explicit timeouts in
  the high-risk tail/country paths, and make `ComposeOutputs` fail closed to an empty payload on
  `RegexMatchTimeoutException`.
- Made HTML entity decoding single-pass by decoding `&amp;` last; decoded invisible controls such as
  soft hyphen are removed after decoding.
- Normalize field/custom text to Unicode NFC before filtering so canonically equivalent NFD input
  such as `Jose\u0301` retains the same accented character as NFC `José`.
- Apply apostrophe-suffix case normalization to the canonical artist/title parts instead of only the
  visible RT string, keeping standalone, RT and RT+ text consistent.
- Tightened degree/temperature and omega/unit replacement boundaries and made compilation cleanup
  conservative enough to preserve natural text such as `Love Song (Best of Friends)`, `Best of Both Worlds`
  and `The Best of Both Worlds`, while retaining clear qualified compilation markers such as
  `Greatest Hits 80s`, `The Essential Michael Jackson` and `The Best of Queen`.
- Refined tight-separator handling so strong metadata markers such as `Deluxe Edition`, `Explicit`
  and `Theme from ...` remain supported without stripping ambiguous natural forms such as
  `Squeaky-Clean` or `Hero-Epic Movie Soundtrack`.
- Tightened the Core raw-metadata safety limit from 4096 to 1024 characters. The 64-KiB file-level
  guard remains unchanged; the lower Core limit bounds work before regex-heavy sanitizer processing.
- Expanded Core self-tests from 73 to 158 cases with positive and negative regressions for all of the
  above preservation/robustness changes.

### Compatibility

- Settings schema, input/output filenames, delimiter behavior and RT+ target formats are unchanged.
- Clear full-country metadata forms such as `Belgium - Song Title`, `Belgium- Song Title`, and
  whitelisted tight multi-word forms such as `The Netherlands-Walk Along` remain supported.
- Ambiguous country-code-only prefix/title cleanup is intentionally non-destructive; artist-only
  uppercase bracketed ISO2 region suffixes remain supported as a narrowly scoped cleanup rule.
- No migration is required from v3.0.0 through v3.0.3.

## v3.0.3 — 2026-09-30

Small responsiveness and UI-legibility maintenance release.

### Changes

- Reduced the special empty-title / artist-only split-write quiet period from 600 ms to 100 ms.
  Very short partial writes are still absorbed, while a genuine `Artist<delimiter>` record no longer
  incurs a visibly long delay. If a title arrives later, the normal hybrid input monitor detects the
  file update and republishes the completed metadata.
- Kept the existing round status-leader dots but doubled their centre-to-centre pitch to the
  Colour Lab-selected 200%, making long leaders less separator-like without changing dot shape,
  thickness or semantic colour.
- Precomputes the fixed 200% leader dash pattern once instead of recalculating it and allocating a
  new dash array on every leader repaint. Visual output is unchanged.
- Replaced the quantized LAST UPDATE colour ramp with explicit thresholds: healthy below 5 minutes,
  warning from 5:00 through 14:59, and error from 15:00 onward. This makes
  `HealthCriticalAtSeconds = 900` actually become critical at 15 minutes.
- Increased `TextMuted` from RGB `105/105/105` to `125/125/125`.
- Increased separator-line RGB from `82/82/82` to `100/100/100`.
- Updated the Colour Lab defaults to the v3.0.3 palette and 200% round-dot spacing, and corrected
  its `WORKING DIR` label so the label uses the same healthy green as the path value.

### Compatibility

- Settings schema, input/output filenames, delimiter behaviour and RT+ target formats are unchanged.
- No migration is required from v3.0.0, v3.0.1 or v3.0.2.

## v3.0.2 — 2026-09-29

- Release verification: extracted `AppLog` into its own source file and added it to every direct-csc application/self-test build, so Phase 4-7 harnesses compile with the v3.0.2 logging calls.

Runtime/input hardening maintenance release.

### Changes

- Fixed the text-decoding fallback: UTF-8 is now decoded strictly so invalid byte sequences actually
  fall back to the Windows default code page; U+FFFD replacement characters are stripped defensively.
- Metadata containing more than one configured delimiter now fails closed as `INVALID` instead of
  being concatenated into corrupt artist/title output.
- Added two layers of pathological-input protection: input files above 64 KiB are rejected before a
  full read, raw metadata above 4096 characters is rejected by the processing engine, the static
  regex cache is enlarged, and sanitizer regex operations receive a default match timeout.
- Hardened RT+ output against formatter/tag injection. Stereo Tool values now escape its documented
  formatted-text control characters (`<`, `>`, `|`, `:`, `/`, `\`); Magic RDS 4 values cannot inject
  additional angle-bracket RT+ tags.
- Recoverable exceptions while processing one metadata update no longer terminate the runtime worker.
  The update fails closed, outputs are cleared, the incident is logged, and the next update is processed.
- Added application diagnostics in `%LOCALAPPDATA%\Sanitize NowPlaying\SanitizeNowPlaying.log` with
  simple size rotation; fatal worker/UI/startup failures and corrupt-settings fallback are recorded.
- Corrupt settings still fall back to safe defaults for compatibility, but the fallback is no longer
  diagnostically silent.
- Removed reflection from custom-text validation. The UI now calls the same public Core conversion
  path directly and delegates normalization to Core, eliminating duplicated normalization logic.
- Removed Ctrl+C as an Exit shortcut, changed the footer hint to Alt+F4, and added a rounded in-app
  modal exit confirmation with explicit `EXIT` / `CANCEL` actions; Cancel is the safe default because
  normal shutdown clears all output files, including files that pre-date the current session. The confirmation uses the neutral UI palette rather
  than the warning colour, because normal application shutdown is not an error/degraded state.
- Expanded Core and Runtime regression tests for multi-delimiter input, oversized input, replacement
  characters, legacy/default-codepage decoding, RT+ injection/escaping and corrupt-settings diagnostics.
- Clarified the main-screen invalid-input status from `INVALID` to `INVALID DATA`, so it describes
  malformed metadata content rather than implying that the input file itself is invalid.
- Corrected the v2.1.8 parity smoke corpus so the intentional v3.0.2 multi-delimiter fail-closed
  divergence is excluded from the suite of *unaffected* compatibility cases.
- Cleaned up repository presentation without changing runtime behavior: obsolete phase scripts,
  phase reports and superseded release artifacts are archived under `docs/history/`, while the root
  retains only the active release workflow and its required helper scripts.

### Compatibility

- Settings schema and output filenames are unchanged.
- The no-delimiter title-only fallback remains supported.
- Inputs with multiple configured delimiters now intentionally fail closed rather than following the
  legacy concatenate-as-title behaviour.
- No migration is required from v3.0.0 or v3.0.1.

## v3.0.1 — 2026-09-28

Sanitizer safety/hardening maintenance release.

### Changes

- Hardened adjacent comma-prefix artist deduplication so destructive comparisons keep meaningful
  parenthetical and `of/from` qualifiers. The intended `Steve Harley, Steve Harley & Cockney Rebel`
  cleanup remains supported while distinct same-name credits are preserved.
- Applied the same strict-identity rule to bracketed artist-prefix deduplication.
- `Mono` / `Stereo` are now removed only when clearly marked as technical suffixes (for example
  `(Mono)`, `[Stereo]`, `- Stereo`, `/ Mono` or `| Stereo`), preserving legitimate titles such as
  `Life in Mono`.
- Duplicate-title cleanup now requires the complete normalized title parts to match and no longer
  discards arbitrary trailing bracket qualifiers; e.g. `Song (Part 1) - Song (Part 2)` is preserved.
- Apostrophe case cleanup no longer damages intentionally all-caps text such as `DON'T` or `O'JAYS`,
  while still correcting accidental mixed-case suffixes such as `John'S`.
- Updated the processing-engine description: v2.1.8 remains the compatibility baseline, but v3.0.1
  intentionally contains conservative safety hardening and therefore no longer claims universal
  byte-for-byte processing parity with the legacy implementation.
- Expanded the processing-engine self-test suite with v3.0.1 regression cases and clarified the
  legacy parity smoke test as coverage for unaffected baseline cases.

### Compatibility

- Settings schema, output filenames, delimiter behaviour, RT+ targets and runtime/UI behaviour are
  unchanged from v3.0.0.
- No migration is required from v3.0.0.

## v3.0.0 — 2026-09-27

First public release of the C# / WinForms generation.

### Major changes from v2.1.8

- Complete rewrite from PowerShell/conhost to C# / .NET Framework 4.8 WinForms.
- Standalone graphical application; no PowerShell or console host required at runtime.
- New v3 application icon and product identity.
- Vendor-neutral product name `Sanitize NowPlaying`; platform names are used only for target-specific integration.
- Fixed delimiter-menu column alignment so custom delimiters of 1–5 characters align consistently.
- Restored human-readable multi-line settings JSON formatting (one setting per line).
- Preserves the v2.1.8 sanitizing/output contract with exact parity regression coverage.
- Transactional in-app Settings UI with nested overlays and custom text editors, a visually separated `Save & exit` commit action, fixed right-aligned value columns, a more compact prefix selector, harmonized full-row bottom padding, and dedicated separator gutters that never share a text baseline.
- Settings, child, grandchild and deeper active overlays can all be repositioned by dragging their header.
- Simplified overlay keyboard UX: Enter confirms, Esc goes back/cancels, while Left/Right are reserved for text-caret movement only.
- Added a subtle draggable-header hover highlight with matching text brightening across menu overlays and an in-app `About` child overlay showing product/version/copyright information in the standard content colour.
- Fixed compact choice-overlay header overflow and added defensive header clipping.
- Compact 25-row main UI with semantic health/status colours and regression-checked row mapping.
- First-run Working Directory setup and internal folder/volume picker.
- Configurable input filename (default `nowplaying.txt`) integrated into the Working Directory picker and first-run setup, including existing-file selection, manual entry, clearer semantic sections, bright standalone folder actions, supported plain-text extension filtering (`.txt`/`.log`/`.dat`/extensionless), Windows filename validation and output-file collision protection.
- Configurable RT+ output target for `nowplaying_rtplus.txt`: Stereo Tool remains the backward-compatible default, with Magic RDS 4 inline `Item.Artist` / `Item.Title` tag output as an alternative.
- Network Working Directory availability/status handling and automatic reconnect.
- Persisted mapped/UNC Working Directories are preserved when temporarily offline at startup; the app starts in OFFLINE/reconnecting state instead of silently switching to a local fallback or reopening first-run setup.
- Settings commits are fail-safe: an atomic settings-save failure leaves the existing runtime running, while runtime-switch failures roll the persisted settings back to the previous configuration.
- Runtime worker shutdown now verifies that the old worker actually stopped before a replacement can start, preventing overlapping workers after delayed I/O.
- Artist-only split-write handling now requires a meaningful quiet period before accepting an empty-title record, covering playout writers that complete the title hundreds of milliseconds later.
- Six individually atomic UTF-8/no-BOM output files.
- Exact failed-payload output retry and LastGood update protection.
- Fatal worker errors fail safe by clearing derived UI content and attempting to clear all six output files.
- Explicit EMPTY / MISSING / EXPIRED / UNAVAILABLE / INVALID runtime states.
- Consistent warning/status colour policy and right-side status leaders.
- Accelerated regression/stress suite, including fuzzing, concurrent file/settings access,
  partial writes, watcher storms, locks, lifecycle cycles and memory plateau checks.
- Release packaging now verifies/builds by default, checks staging errors, and never relies on a stale prebuilt EXE.
- Cleaned obsolete private helpers, synchronized all no-sparkle icon assets, removed stray editor backup files, normalized legacy `.csproj` import ordering, and added source-tree hygiene rules.

### Compatibility

- Existing `Sanitize-NowPlaying.settings.json` format retained.
- Output filenames retained.
- Processing parity reference remains PowerShell v2.1.8.
- AnyCPU build: normally 64-bit on 64-bit Windows and 32-bit on 32-bit Windows.

### Known limitation

Mapped-network recovery may take several seconds after Windows reports that connectivity has
returned. The application deliberately remains OFFLINE until the runtime watcher/input path has
recovered safely.
