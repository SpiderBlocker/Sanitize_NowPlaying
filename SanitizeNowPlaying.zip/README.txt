Sanitize NowPlaying
v3.0.4
===================

Sanitize NowPlaying reads playout metadata from a file in the configured Working Directory,
sanitizes it, and produces separate UTF-8 output files for RDS / RT+ workflows,
including Stereo Tool and Magic RDS 4. The default input filename is nowplaying.txt.

System requirements
-------------------
- Windows 10 or Windows 11
- .NET Framework 4.8
- No PowerShell or console host is required at runtime.
- The application is portable, but its folder must be writable by the current user because the
  settings JSON is stored next to SanitizeNowPlaying.exe.

First start
-----------
1. Start SanitizeNowPlaying.exe.
2. Select the Working Directory containing the playout metadata file and confirm it.
   nowplaying.txt is used as the default input filename.
3. If another input filename is required, open F10 Settings > Working directory and use
   I  Input file to select an existing file in the browsed folder or enter a filename manually.
4. Configure prefix, connector, artist/title order, transliteration, ASCII-safe mode and delimiter
   as required from Settings.

Settings UI
-----------
The active Settings window or nested child window can be repositioned by dragging its header.
Changes remain transactional: only Save & exit commits them.

Generated output files
----------------------
- prefix.txt
- artist.txt
- connector.txt
- title.txt
- nowplaying_rt.txt
- nowplaying_rtplus.txt

Compatibility
-------------
v3 is the C# / WinForms successor to the PowerShell/conhost v2 series. It uses the v2.1.8
processing contract as its compatibility baseline and preserves the existing
Sanitize-NowPlaying.settings.json format. v3.0.2 added malformed-input, decoding, RT+ escaping,
worker-recovery and diagnostics hardening on top of the v3.0.1 sanitizer fixes. v3.0.3 kept that
contract and added a shorter 100 ms artist-only guard plus small status/contrast refinements.
v3.0.4 keeps the same settings/output contract while making destructive sanitizer rules more
preservation-first, adding Core regex-timeout fail-closed behavior, and aligning Unicode/entity
normalization across standalone, RT and RT+ output.

Mapped network drives
---------------------
Loss of a mapped network Working Directory is detected quickly and shown as OFFLINE. A mapped/UNC
Working Directory that was already confirmed remains selected even if it is offline when the app
starts; no local fallback is substituted. After Windows reconnects the mapping, full runtime
recovery can take several additional seconds (in observed
cases sometimes around 10 seconds) while Windows/SMB and FileSystemWatcher become fully ready.
The application remains OFFLINE until recovery has completed.
