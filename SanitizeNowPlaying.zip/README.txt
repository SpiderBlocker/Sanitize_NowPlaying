Sanitize NowPlaying v3.0.0
=============================

Standalone Windows application for sanitizing playout metadata into
RDS RadioText (RT), RT+ and separate component output files.

REQUIREMENTS
------------
- Windows 10 or Windows 11
- .NET Framework 4.8

INSTALLATION
------------
1. Extract this ZIP to a folder in which your Windows account has write access.
2. Run SanitizeNowPlaying.exe.
3. On first start, select the Working Directory used by your playout software.
4. Configure the playout software to write artist/title metadata to the selected
   input file. The default filename is nowplaying.txt.
5. Use F10 Settings to change the Working Directory, input filename, prefix,
   artist/title order, connector, ASCII/transliteration options, delimiter or
   RT+ output target.

The application stores Sanitize-NowPlaying.settings.json next to the executable.

OUTPUT FILES
------------
The selected Working Directory can contain:

- prefix.txt
- artist.txt
- connector.txt
- title.txt
- nowplaying_rt.txt
- nowplaying_rtplus.txt

Output files are written as UTF-8 without BOM and are replaced atomically.

RT+ OUTPUT
----------
Stereo Tool is the backward-compatible default RT+ output target.
Magic RDS 4 can be selected as an alternative target in F10 Settings.

VERSION LINEAGE
---------------
v3.0.0 is the direct successor to v2.1.8, the final PowerShell/conhost release.
v3 is a complete C# / .NET Framework 4.8 WinForms rewrite while preserving the
established settings compatibility, output filenames and processing behaviour.

LICENSE
-------
Sanitize NowPlaying v3.0.0 and later are distributed under the proprietary
license included in LICENSE.txt.

Historical v2.x releases were distributed under GNU GPLv3 and remain under
those original terms.

Copyright (c) 2026 Loenie. All rights reserved.

PROJECT
-------
https://github.com/SpiderBlocker/Sanitize_NowPlaying_for_Stereo_Tool
