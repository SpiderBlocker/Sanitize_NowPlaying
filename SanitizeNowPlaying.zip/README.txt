Sanitize NowPlaying
v3.1.1
===================

Requirements
------------
Windows 10/11 and .NET Framework 4.8. No PowerShell or console host is required
at runtime. The portable application folder must be writable: settings are stored
beside SanitizeNowPlaying.exe as Sanitize-NowPlaying.settings.json.

First start and settings
------------------------
Select the input folder in initial setup. The input filename defaults to
nowplaying.txt and can be selected/entered during setup or under F10 Settings >
Input settings > Input file. Playout delimiter is in the same Input settings menu.
The default output folder follows input; choose an independent folder under
Output settings > Output folder. The six UTF-8 output filenames are unchanged:
prefix.txt, artist.txt, connector.txt, title.txt, nowplaying_rt.txt,
nowplaying_rtplus.txt. RT+ targets are Stereo Tool and Magic RDS 4.


Folder selection
When input and output share a folder, setup and the F10 picker require read and
write access. An unwritable choice stays in the picker with a warning. Read-only
input is allowed with a separate output destination. Later write-access changes
still produce WRITE FAILED at the affected output files until access recovers.
OUTPUT DIR reports availability only: CHECKING during the availability check
and both folder rows show UNAVAILABLE when inaccessible or missing.
A reachable folder remains normally displayed
when file writes fail; detailed errors remain in the output-path tooltip.
A deleted or renamed folder is not automatically recreated during monitoring,
publication, retry, clearing or shutdown. Its configured path is retained:
restore that path or select another folder explicitly. New folder creation
remains available in the pickers; the existing startup wizard for missing
local input folders is retained.

The twelve sanitizer rules default to On, case to Original and output to the
input folder, retaining v3.0.4 defaults. Unicode/ASCII-safe, transliteration,
prefix/connector, artist/title order, text case and RT+ target are configurable.
ASCII-safe requires transliteration; use Unicode to change its effective setting.

Messages
--------
Short notices remain on one line. Longer messages wrap without shortening their
text and use a higher message box; the main/setup window size does not change.
Wrapped messages remain visible for at least eight seconds. Unusually long
messages use an OK notice. Long diagnostics can be scrolled and selected/copied
in full. Acknowledgement preserves the open menu and uncommitted settings.

Menu behavior
-------------
The 1008x500 main screen has Rules, Chars, Translit, Case and Order on one footer
row, with compact F10 Settings / Alt+F4 Exit at the bottom right. INPUT DIR and
OUTPUT DIR keep the full row width. Truncated values have full-value tooltips.
Rules uses checkboxes; single choices use radio markers. Focus is dark gray with
light text; mouse hover is subtler. Initial setup uses the same row styling.
Quick popups have no headers and leave the main screen undimmed. Rules stays open
for successive immediately saved toggles; other quick choices close after a
successful save. Esc/outside click/focus loss dismisses them. Failed saves keep
the old value and allow retry. Tab/Shift+Tab moves footer focus; Enter/Space opens
the focused field. In a popup, Up/Down moves choices and Left/Right switches
between available quick menus; Tab dismisses and moves footer focus.
ASCII-safe makes Translit gray and prevents its quick menu opening. Hover still
explains why it is required. Tab/Shift+Tab and popup arrows skip it; Unicode
restores editing. F10 uses the same setting explanations and forced-mode help.

Every sanitizer rule has the same explanation in both Rules menus after a short
hover or keyboard-focus pause. Help disappears on navigation/menu close. Language
tags remains separate from geographic tags. Redundant artist abbreviations
removes matching suffixes such as (CCR) after the full artist name. A subtle
divider separates metadata rules from the three name/duplicate rules.

Dialogs place assistance left and confirmation / Cancel right, using one shared
button style, height, measured padding and feedback. Confirmation is subtly
brighter. Apply, Save & exit, Exit and OK follow the same policy. Selected radio
buttons have a light fill and dark centered dot, matching checkbox fill/tick ink.

Folder pickers keep Volume / New folder left; initial setup also keeps Input file
there. Use this folder / Cancel stay right while Folders scrolls. U confirms the
displayed full-width current path. In both file pickers, row clicks only select;
Selected file shows the candidate and Use this file, U or Enter confirms it.
Cancel leaves the candidate unapplied. Manual filename stays left. Inactive
parent frames, separators and buttons are dimmed consistently; menu size,
centering and dragging retain their existing policy.

F10 edits a draft. Save & exit applies it and closes only the settings menu.
The close question is titled Save changes?.
Closing the root via outside click, Esc, X or F10 closes directly if unchanged
or reverted. With pending edits, choose Save & exit, Discard changes or Cancel.
Cancel is selected by default; Cancel/Esc/X returns with the draft intact.
Failed saves retain the draft for retry. Esc/outside click in a submenu returns
to the parent. Restore defaults remains in F10 Sanitizer
rules and resets the draft only. Choices/toggles accept Enter/Space; commands and
pickers use Enter. Text editors retain literal spaces and selected-text styling.
F10 submenus initially center on their immediate parent, clamped only by the main
window boundary. Dragging their headers retains the chosen position. F10 and Exit
dim the underlying main screen. Exit confirmation defaults to Cancel and clears
outputs on normal confirmed shutdown.

Clock skew and settings recovery
--------------------------------
At startup, reconnect and input-path changes, timestamps up to 300 seconds in the
future can publish. The old-file freshness limit remains 180 seconds. Larger future
offsets remain EXPIRED. Keep the playout/NAS and local clocks synchronized.
Unreadable settings produce a controlled startup error with the full settings path
and leave the file intact. Malformed/non-object JSON uses defaults in memory with
a logged warning. Before Save replaces it, a unique .bak in settings-backups beside
the executable preserves its original bytes, BOM and encoding. If the backup fails,
Save is rejected; the current runtime and original settings remain intact. Earlier
backups are retained. Recovery names use c-<compact GUID>.bak: all GUID bits are
retained, with a shorter full path than the existing settings temporary-file path.
Earlier timestamp/name backups remain untouched. Valid settings saves create no copies.

Compatibility and limitations
----------------------------
Artist-only behavior is retained: with default cleanup, Artist + delimiter + empty
title clears outputs; Artist + delimiter + (Live) can reduce to Artist; empty artist
+ delimiter + Title publishes Title. The reader's quiet-period guard only ensures
a stable read. Output formats and the additive settings schema are unchanged.
Single instance is per Windows logon session (Local mutex), not across sessions or
PCs. Use one writer per output folder. Each output file is atomic; the six-file set
is not. Offline outputs are retried in place, never redirected to another folder.
Normal shutdown clearing is bounded/best-effort for unreachable destinations.
Use UTF-8 input for Vietnamese and other Unicode text. ASCII-safe is intentionally
lossy and does not romanize every script. Native fonts/encoder repertoire matter.
Downgrading to 3.0.4 ignores new fields and writes outputs beside input; an old-version
save can discard the new fields. Keep a settings backup before downgrading.

Diagnostics
-----------
Open %LOCALAPPDATA%\Sanitize NowPlaying\SanitizeNowPlaying.log in a text editor.
The log rotates at about 1 MiB; the preceding copy is SanitizeNowPlaying.log.old.

Source package
--------------
The source package includes build/verification scripts and developer
documentation. The end-user ZIP contains the EXE, this README and CHANGELOG.md.
No build/test scripts are needed to run the application.

Sanitizer-rule behavior in v3.1.1
--------------------------------
Track number recognition stays stable when removal is Off.
Track prefixes before [artist + delimiter + title] also obey this rule;
surrounding filename text remains outside the explicit metadata payload.
Separate trailing labels are processed independently of their order. Live/session labels and
audio/source labels take precedence over generic version words: Live Version
belongs to Live & session tags; Stereo Mix and Serato Edit belong to Audio,
source & release tags. Standalone year tags controls separate year labels;
2002 Digital Remaster is a single version label. Retained guest/live/country
labels survive version and duplicate cleanup. RT, RT+ and standalone fields
still have a 64-character budget; shortened fields display an ellipsis.
